﻿using System;

namespace LabSintaxis2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingresar texto:");
            String inputTexto = Console.ReadLine();
            if (inputTexto.Length >= 1)
                Console.WriteLine(inputTexto);
            else
                Console.WriteLine("Escribime algo te dije lcdtm");
            
        }
    }
}
