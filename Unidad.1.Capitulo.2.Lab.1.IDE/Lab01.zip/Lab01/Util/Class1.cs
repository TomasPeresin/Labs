﻿using System;

namespace Util
{
    public class Class1
    {
    }
}
